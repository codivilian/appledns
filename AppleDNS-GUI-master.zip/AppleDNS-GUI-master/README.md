# AppleDNS-GUI

## 推荐使用[此方法](https://sspai.com/post/35741)解决网络问题


#### [下载](https://github.com/xjbeta/AppleDNS-GUI/releases)
#### 请熟读[AppleDNS](https://github.com/gongjianhui/AppleDNS)相关内容后再使用本APP

#### 给[AppleDNS](https://github.com/gongjianhui/AppleDNS) 的python 命令行套个壳
#### 解压后放入 应用程序(application) 文件夹
#### 仅供测试，不保证能正常运行。
